﻿#ifndef _PCS_BAIDUPCS_H
#define _PCS_BAIDUPCS_H

#define PCS_IMPORT_LIB
#include "pcs.h"

#endif
